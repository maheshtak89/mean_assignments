// run container once it is build
docker run -it -v: usr/src/apps -v /usr/src/apps/node_modules -p 9393:9393 -rm harbingerngapps

// use -d instead of -v for running conatainer in background

// stop conatainer
docker stop <container-id>

// to remove container
docker rm <container-id>




**===========================================================================================**
- Testing the App
    - @angular/<package>/testing folder
        - function / logic / testing
            - Code Unit
            - Event Triggered from UI
        - service testing
            - Service Method Testing
            - Mock for External Dependancies
        - Test Platform
            - TestBedEnvironment
            - PlatformBrowserDynamicTestingModule
                - Manage additional Dependancies
            - Mock
        - Engine
            - Jasmin
                - Arrange
                - Act
                - Assert
            - Karma
                - Load the browser Process
                - Manage all external dependancies
                - Load the angular Object
            - Karma+Jasmin+Nrowser Launcher
                - karma.config.js
                    - npm install -g karma
                    - karma init command
    - @angular/cli
        - An integration with
            - Angular ObjectModel + Angular TestModel + Test Engine
            - npm install -g @angular/cli
                - ng tool
                    - new   => To create a new angular app
                    - generate
                        - generate
                            - component
                            - service
                            - directives
                    - build
                        - optimized build based on AoT
                    - start
                        - Execute
                    - test
                        - Used Angular Testing object model
                            - test.ts file
                                - <FileName>.<FileType>.spec.ts
                                    - FileType
                                        - Component
                                        - Service
                                        - Directive
                    - lint
                        - Language quality check before Check-In