import { Component, OnInit, Input } from '@angular/core';
import { Item, items } from "./app.items.model";

@Component({
    selector: 'app-ItemList-component',
    template: `
        <h2>Order List </h2>

        <h2> Number or Orders are : {{this._counter}}</h2>
        <div class="container">
            <table table-bordered table-striped border="2" cellspacong="2" cellpadding="2" align="center">
                <thead>
                    <tr>
                        <td> Item Id</td>
                        <td> Item Name </td>
                    </tr>
                </thead>
                <tbody>
                    <tr *ngFor = "let i of items" (click)="selectedItem(i)">
                        <td>{{i.id}}</td>
                        <td>{{i.name}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <br/>
        <br/>
       
    <app-Order-component [ItemNo]="itemNo" (valueChangeEmitter)="getCounter($event)"></app-Order-component>

    `
})
export class ItemList implements OnInit {
    item: Item;
    items = items;
    
    itemNo: number;
    
    _counter: number = 0;
    constructor() { 
        this.itemNo = 0; 
    }

    ngOnInit(): void { }

    selectedItem(item: any):void{
        this.itemNo = item.id;
        console.log(this.itemNo);

    }

    getCounter(counter: number):void{
        console.log("Counter get :"+this._counter)
        this._counter = counter;
    }
}
