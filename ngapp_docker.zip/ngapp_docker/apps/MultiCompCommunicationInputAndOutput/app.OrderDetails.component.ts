import { Component, OnInit, Input , EventEmitter, Output} from '@angular/core';

import { OrderDetail, orderDetails } from "./app.orderDetails.model";

import { template } from '@angular/core/src/render3';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';

@Component({
    selector: 'app-Order-component',
    template: `
    <h2>Order Details:</h2>
        <div class="container">
            <table table-bordered table-striped border="2" cellspacing="2" cellpadding="2">
                <thead>
                    <tr>
                        <th> Order No </th>
                        <th>Order Type</th>
                        <th> Delivery Status</th>
                        <th> Total Price </th>
                        <th> Item ID</th>
                    </tr>
                </thead>
                <tbody>
                    <tr *ngFor="let o of _FilterOrders">
                        <td>{{o.orderNo}}</td>
                        <td>{{o.orderType}}</td>
                        <td>{{o.deliveryStatus}}</td>
                        <td>{{o.totalPrice}}</td>
                        <td>{{o.id}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    `
})
export class OrderComponent implements OnInit {

    orderDetail : OrderDetail;
    orderDetails = new Array<OrderDetail>();
    _FilterOrders: Array<OrderDetail>;
    //@Input()
    _itemNo: number;

    counter: number = 0;

    
    @Output() 
    valueChangeEmitter: EventEmitter<number>;
   
    @Input()
    set ItemNo(id: number){
        this._itemNo = id;
        console.log(`item No from ItemComponent ${this._itemNo}`);
        this.ItemNo;
    }

    get ItemNo(){
        console.log(` get executed with itemNo: ${this._itemNo}`)
        this.filterOrders;
        return this._itemNo;
    }
    

    //@Input()
    get filterOrders() {
    console.log(`in filter`);
    this._FilterOrders = new Array<OrderDetail>();
    for(let order of orderDetails){
        if(order.id === this._itemNo){
            console.log("Product pushed..")
            this._FilterOrders.push(order);
            this.valueChange();
        }
    }   //console.log(this._FilterOrders);
    return this._FilterOrders;  
}
    constructor( ) {
        this._FilterOrders = new Array<OrderDetail>();
        console.log("Constructor executed..")
         //console.log(this._FilterOrders);

         this.valueChangeEmitter = new EventEmitter<number>();
         //this.filterOrders();
     }

     valueChange():void{
         console.log("in valueChange()")
        this.counter = this._FilterOrders.length > 0 ? this._FilterOrders.length : 0;
        this.valueChangeEmitter.emit(this.counter);
        console.log("counter:"+this.counter)
     }

    ngOnInit(): void {
        //this.valueChange();
    }
}
