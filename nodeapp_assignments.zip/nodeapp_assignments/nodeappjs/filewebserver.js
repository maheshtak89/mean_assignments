//import { PagesLogic } from "./pagesLogic";
var PagesLogic = require('./pagesLogic');
//for http request
var http = require('http');

//for I/O operations
var fs = require('fs');

//1. create a server object with listener
// var server = http.createServer(function(request, response){
//     //parse the request and read the URL
//     if(request.url==="/home"){                  //if req come to home page
//         //2.a read for home page

//         fs.readFile('./home.html',function(err,data){
//             if(err){
//                 response.writeHead(401, {"Content-Type":"text/html"});              //defining error formate to display
//                 response.write("Resource your looking are not available...");       // message when page not exist
//                 response.end();
//             }
//                 response.writeHead(200, {"Content-Type":"text/html"});              //defining data formate to display
//                 response.write(data);                                               // displaying data
//                 response.end();
//         })
//     }else{
//         if(request.url==="/about"){             // if req  comes to about page
//         //2.b read for about page

        
//         fs.readFile('./about.html',function(err,data){
//             if(err){
//                 response.writeHead(401, {"Content-Type":"text/html"});              //defining error formate to display
//                 response.write("Resource your looking are not available...");       // message when page not exist
//                 response.end();
//             }
//                 response.writeHead(200, {"Content-Type":"text/html"});              //defining data formate to display
//                 response.write(data);                                               // displaying data
//                 response.end();
//         })
//         }
//     }
// });

var server = http.createServer(function(request, response){
    PagesLogic.callPage(request, response);
})
server.listen(4060);
console.log("Server started on port 4060...");
