//1. Create a file and add data in it.

//2. Load the fs module
var fs = require('fs');

//3. write file with Sync call
fs.writeFileSync('./myFile.txt',"I am the Text File");
console.log("File is written");

//4. read the file with Sync call
var data = fs.readFileSync('./myFile.txt');
console.log(data.toString());