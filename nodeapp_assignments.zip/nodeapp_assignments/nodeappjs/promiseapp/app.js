//1.
var http = require('http');
 
var emp = [];
 

console.log("Doing the Post Operations....");
//4
var product = JSON.stringify({
    'BasePrice': 22222222222,
    'CategoryName': 'WWWWWWWWWWWWW',
    'Description': 'XXXXXXXXXXXXXXXX',
    'Manufacturer': 'IBMIBMXXXXXXXXXXXXXXXXXIBMIBM',
    'ProductId':388888888888,
    'ProductName':'ZZZZZZZZZZZZZZZZZZZZZZZZZZZ',
    'ProductRowId':2
});
 
 
//5
var extServerOptionsPost = {
    host: 'apiapptrainingservice.azurewebsites.net',
    path: '/api/Products',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': product.length
    }
};
 
 
 
//6
var reqPost = http.request(extServerOptionsPost, function (res) {
    console.log("response statusCode: ", res.statusCode);
    res.on('data', function (data) {
        console.log('Posting Result:\n');
        process.stdout.write(data);
        console.log('\n\nPOST Operation Completed');
    });
});
 
// 7
reqPost.write(product);
reqPost.end();
reqPost.on('error', function (e) {
    console.error(e);
});
 console.log("Done..");
// get();