//1. load q

var q = require('q');

//2. load http to make external call
var http = require('http');

var prod = [];

//3. define module

module.exports = {
    
    //3.1 function to make call using http object
    // this function must accept server information
    // server onfo will be a.) host b.) path c.) method
    //host --> host address IP/NAME
    //path --> uri path aka  resoource Name or Rest API address
    //method --> GET/POST/PUT/DELETE
    // headers -->{AUTHORIZATION} if its required
    //this function will return promise

    // if the method recieve success then defer will be resolve else rejected
    getData:function(options){
            //4. create defferer object using q
            var defer = q.defer();
            var product="";
            var request;
            // var response;           // represent response
            // var responseData;       // represent response data

            if(!options){
                defer.reject('Server info not available')
            }else{
                        request =  http.request(options, function(response){
                            response.setEncoding('utf-8');
                            response.on('data', function(chunk){
                                //prod = JSON.parse(chunk)
                                product += chunk;
                            });//response.on
                            response.on('end',function(){
                                try{
                                    var receivedJSON =  JSON.parse(product.toString());
                                    defer.resolve(receivedJSON);
                                }catch(err){
                                    defer.reject(err);
                                }//catch
                            });//response.on
                    });//else
                        ///////////////////////////////////////////////////////
                    //     response = http.request(options, function(data){
                    //         // 4.a  start receiving data 
                    //         response.on('data', function(data){
                    //             responseData =+ data;
                    //         });
                    //         //4.b once data processing is done complete/end the call
                    //         response.on("end", function(data){
                    //             try{
                    //                 // if end successfully then resolve
                    //                 var responseData = JSON.parse(responseData);
                    //                 defer.makeNodeResolver(responseData);
                    //             }catch(err){
                    //                 // else reject and return error
                    //                 defer.reject(`Some error occured ${err}`)
                    //             }
                    //         }) 
                    //     });
                    // }
                    //5 end the response
                    request.end();
                    //<NUMBER UNKNOWN>
                    //6. return promise
                    return defer.promise;
            }//else
 }//getData()
}//module.export

// module.exports = {
//     //Under progress

//     postData:function(optionsData){

//     }//postData()
// }