var caller =require('./getexternaldata');

//1. defnie server options
var options = {
    host:"apiapptrainingservice.azurewebsites.net",
    path:"/api/Products",
   // method:"GET"
   method:"GET"
};

// 2.call the method from module and subscribe to promise

caller.getData(options).then(function(receiveData){
    console.log(JSON.stringify(receiveData)).catch(function(err){
        console.log(err)
    });
}).catch(function(err){
console.log(err);
});

console.log("Done get");

var optionsPost = {
    host:"apiapptrainingservice.azurewebsites.net",
    path:"/api/Products",
   // method:"GET"
   method:"POST"
};

//Under progress

// caller.getData(options).then(function(receiveData){
//     console.log(JSON.stringify(receiveData)).catch(function(err){
//         console.log(err)
//     });
// }).catch(function(error){
// console.log(error);
// });

// console.log("Done");
