
//writing object util and importing .js file in that
var util = require('./utilitymodule');
var math = require('./wholemodule')
var str = "Node.js";
console.log(`Case with uppercase for ${str} is ${util.caseuntility(str,"U")}`);
console.log();
console.log(`Case with lowercase for ${str} is ${util.caseuntility(str,"L")}`);
console.log()
//console.log(`Case with reverse string for ${str} is ${util.reverse(str)}`);


console.log(`addition ${math.add(5,6)}`);

console.log(`multiplication ${math.multi(5,6)}`);
