var fs =require('fs');

//1. write file using Async call
fs.writeFile('./myasyncfile.txt',
                    "This is my Asynchronous File",function(err){       //error handling code
                        if(err){
                            console.log("Error: "+err.message)          //display error
                            return;
                        }
                        console.log("File written succesfully..");


                        //read file using readFileAsync
                        fs.readFile('./myasyncfile.txt',function(err,data){     //error handling code
                            if(err){
                                console.log("Error: "+err.message);
                                return;
                            }
                            console.log(data.toString());
                        });


                        // fs.mkdir('./myNewFile.txt',function(err,
                        //     //read data from file and append
                        
                        //     ){
                        //    if(err){
                        //        console.log("Error (while appending) :"+err.message);
                        //    }
                        //    console.log(data);
                        // })
});


// fs.appendFileSync()
// fs.mkdir('./myasyncfileNew.txt');


// here we are appending some data in existing file.
fs.appendFile('./myasyncfile.txt'," I Appended this data with existing file",function(err){
    if(err){
        console.log("Error (while appending) :"+err.message);
        return;
    }

    // console.log(
    //     fs.readFile('./myasyncfile.txt',function(err,data){
    //         if(err){
    //             console.log("Error (while reading):"+err.message);
    //         }
    //         console.log(data);
    //     });
    // )
});

fs.mkdir('./myNewFolder',function(err){
    if(err){
        console.log("Error :"+err.message);
        return;
    }
})



// fs.writeFile(
//     fs.mkdir('./myLatestFolder',function(err){
//         if(err){
//             console.log(err.message);
//         }
//     }),+'/.mynewFile.txt',"Hi mahesh",function(err){
//         if(err){
//             console.log("Error :"+err.message);
//             return;
//         }
//         console.log(data);
//     }
// )
console.log('DONE!');


