
var dt = [
    {"page1":"./page1.html"},
    {"page2":"./page2.html"},
    {"page3":"./page3.html"},
   {"page4":"./page4.html"},
    {"page5":"./page5.html"},
]


class PagesLogic{
    constructor(){
        console.log("PagesLogic() executed..")
    }

    static callPage(request, response):void{
        for(let u of dt){
            if(u===request.url+u){
                var fs = require('fs');
                fs.readFile(request.url,function(err,data){
                    if(err){
                        response.writeHead(401, {"Content-Type":"text/html"});              //defining error formate to display
                        response.write("Resource your looking are not available...");       // message when page not exist
                        response.end();
                    }
                        response.writeHead(200, {"Content-Type":"text/html"});              //defining data formate to display
                        response.write("This is page :"+request.url+data);                                               // displaying data
                        response.end();
                });
            }
        }

        
    }
}