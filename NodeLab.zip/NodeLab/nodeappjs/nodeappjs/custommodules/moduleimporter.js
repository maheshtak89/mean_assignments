var util = require("./utilitymodule");

var str = "node.js";

console.log(`Case with upper for ${str} is ${util.CaseUtility(str,"U")}`);
console.log(`Case with lower for ${str} is ${util.CaseUtility(str,"L")}`);

console.log(`reverse string is ${str} is ${util.reverse(str)}`);