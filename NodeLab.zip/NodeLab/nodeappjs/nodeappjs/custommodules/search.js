const fs = require("fs");

const paths = [
    {url : "/home", path : '../index.html'},
    {url : "/about", path : '../about.html'}
];


exports.page = function(url){
    let pageForm = "";
    for(let i=0; i<paths.length;i++){
        if(url === paths[i].url){
            this.pageForm = fs.readFileSync(paths[i].path,err =>{
                if(err){
                    console.log("Page not found");
                    return;
                }
            });
        }
    }
    return this.pageForm;
};