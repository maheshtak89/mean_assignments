var http = require('http');
const search = require("./search");

var server = http.createServer((req,res)=>{
    let url = req.url;
    let data = search.page(url);
    if(data === ""){
        res.writeHead(401,{'Content-Type':'text/html'});
        res.write("Resource not available");
        res.end();
    }
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write(data);
    res.end();
});

server.listen(4060);
console.log('server strated on port 4060');