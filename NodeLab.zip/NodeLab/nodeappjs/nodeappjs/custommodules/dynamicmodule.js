module.exports = {
    page : "/home", name : './html',
    page : "/about", name : './about'
}