var http = require('http');

var data = [
    {id : 101, name : 'A'},
    {id : 102, name : 'B'},
    {id : 103, name : 'C'},
    {id : 104, name : 'D'},
    {id : 105, name : 'E'}
];

// 1. create server
var server = http.createServer((req,res) =>{
    // res.writeHead(200,{'Content-Type':'text/html'});
    // res.write('hello hell');
    res.writeHead(200,{'Content-Type':'application/json'});
    res.write(JSON.stringify(data));
    res.end();
});


// 2. listen on the port
server.listen(4050);
console.log('server strated on port 4050');