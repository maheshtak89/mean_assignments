var http = require('http');
var fs = require('fs');


http.createServer((req,res) =>{
   fs.readFile('./myasyncfile.txt',(err)=>{
       if(err){
           console.log(err.message);
       }
       console.log(data)

   })
})