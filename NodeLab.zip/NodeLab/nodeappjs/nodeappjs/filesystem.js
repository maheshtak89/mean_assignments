//1. create a file and add data in it

//2. Load the fs module
var fs = require('fs');

//3. write file with sync call
fs.writeFileSync('./myfile.txt','I am the text file');
console.log('file is written');

//4. read file with Sync call
var data = fs.readFileSync('./myfile.txt');
console.log(data.toString());