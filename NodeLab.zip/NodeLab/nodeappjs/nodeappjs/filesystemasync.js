var fs = require('fs');

//1. write file using async call
fs.writeFile('./myasyncfile.txt','This is async file',(err)=>{
    if(err){
        console.log(err.message);
        return;
    }else{
        console.log('file written successfully');
    }
    fs.readFile('./myasyncfile.txt',(err,data) =>{
        if(err){
            console.log(err.message);
            return;
        }
        console.log(data.toString());

        fs.appendFile('./myasyncfile.txt',data.toString(),(err)=>{
            if(err){
                console.log(err.message);
            }
            console.log('file appended successfully');
        })
    });
});

fs.writeFile('./myasyncfile.xls','This is async file',(err)=>{
    if(err){
        console.log(err.message);
        return;
    }else{
        console.log('file written successfully');
    }
    fs.readFile('./myasyncfile.xls',(err,data) =>{
        if(err){
            console.log(err.message);
            return;
        }
        console.log(data.toString());

        fs.appendFile('./myasyncfile.xls',data.toString(),(err)=>{
            if(err){
                console.log(err.message);
            }
            console.log('file appended successfully');
        })
    });
});


// fs.mkdir('./rahul', (err) =>{
//     if(err){
//         console.log(err.message);
//     }
//     console.log('Folder Created succesfuuly...');
// });

console.log('done');