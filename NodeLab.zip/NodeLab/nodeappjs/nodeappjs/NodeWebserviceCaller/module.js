var q = require('q');
var http = require('http');

module.exports = {
    postData : function(options,data){
        var defer = q.defer();
        var request;
        if(!options){
            defer.reject('Please specify header option to receive data');
        }else{
            request = http.request(options,function(response){
                response.on('data', function(chunk){
                    process.stdout.write(chunk);
                }); 
                response.on('end',function(){
                    try{
                        Console.log(receiveJson);
                        defer.resolve();
                    }catch(error){
                        defer.reject(error);
                    }
                });
            });
        }
        console.log("pass");
        request.write(data);
        request.end();
        return defer.promise;
    }
};