var http = require('http');
var fs = require('fs');
var callModule = require('./module');

var productPage = fs.readFileSync('./input.html');

var productData = ' ';

var server = http.createServer((req,res) =>{
    if (req.method === "GET") {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(productPage);
    }
    if(req.method === "POST") {
        productData = ' ';
        req.on('data', function( prd ) {
            productData += prd;
        }).on('end',function(){
            var product = getJson(productData);
            var options = {
                host: 'apiapptrainingservice.azurewebsites.net',
                //port: '4060',
                path: '/api/Products',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length':  JSON.stringify(product).length
                }
            };
            console.log(JSON.stringify(product).length);
            console.log(product);
            callModule.postData(options,product).then().catch();      
            console.log('The received data is ' + productData.toString());
            res.end('Data received  from you is ' + productData.toString());
        });
    }
});

function getJson(productData){
    var Product = {};
    var KeyValues  = productData.split("&");
    console.log(KeyValues);
    for(var i = 0 ; i<= KeyValues.length-1;i++){
    
        var KeyValue = KeyValues[i].split("=");
        // item = {}
        var key =  KeyValue[0];
        Product[key] = KeyValue[1];
        //Product.push(item);
        //item ["email"] = email;
        // Product.push(KeyValue);
        //console.log(Product)
        // console.log(KeyValue);
       
        //Product[key] = KeyValue[1].toString();
    }
    return Product;
}

server.listen(4060);
console.log('Server started on  4060');