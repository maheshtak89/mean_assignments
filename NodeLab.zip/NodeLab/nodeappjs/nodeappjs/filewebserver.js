var http = require('http');
var fs = require('fs');


var data = [
    {page : "/home", path : './html'},
    {id : "/about", name : './about'}
];

//1. server object

var server = http.createServer((req,res)=>{
    //2. pass req and read url
    if(req.url === "/home"){
        //2a. read from home page
        fs.readFile('./home.html',(err,data) =>{
            if(err){
                res.writeHead(401,{'Content-Type':'text/html'});
                res.write("Resource not available");
                res.end();
            }
            res.writeHead(200,{'Content-Type':'text/html'});
            res.write(data);
            res.end();
        });
    }else{
        if(req.url === "/about"){
            //2a. read from home page
            fs.readFile('./about.html',(err,data) =>{
                if(err){
                    res.writeHead(401,{'Content-Type':'text/html'});
                    res.write("Resource not available");
                    res.end();
                }
                res.writeHead(200,{'Content-Type':'text/html'});
                res.write(data);
                res.end();
            });
        }
    }
});

server.listen(4060);
console.log('server strated on port 4060');