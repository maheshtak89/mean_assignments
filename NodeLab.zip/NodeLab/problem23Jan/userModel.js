var express = require('express');
var path = require('path');
var BodyParser = require('body-parser');
var instance = express();
var mongoose = require('mongoose');
var validateModel = require('./validateModule')
mongoose.Promise = global.Promise;

    instance.use(
        express.static(
            path.join(__dirname,'./../node_modules/jquery/dist/')
        )
    );

var router = express.Router();
instance.use(router);
instance.use(BodyParser.urlencoded({extended:false}));
instance.use(BodyParser.json());

//4.5   Model schema mapping with collection of MongoDB and establishing connection with it.
            mongoose.connect(
                "mongodb://localhost/ProductsAppDB",    // this URL is connection string
                {useNewUrlParser:true}                  // its, establishing the parser for parsing connection string as per version of Mongo
            );

            var dbConnect = mongoose.connection;
    if(!dbConnect){
        console.log("Sorry, Connection is not established..");
        return; // will return directly..
    }
    var userSchema = mongoose.Schema(
            {
                username:String,                       // as per ES6 number not allowed, it should be Number
                password: String
            }
        );

    var userModel = mongoose.model(
        "userModel", //friendly name
        userSchema,     //schema
        "userModel"      //collection name
    )

instance.post("/api/user/", function(request, response){
    var user = request.body;

    var isAuth = validateModel.validateReq(request, response);
    
    if(isAuth){
        userModel.create(user, function(err, res){
            if(err){
                response.statusCode = 500;
                response.send({ status : response.statusCode, error:err});
            }
            console.log(user.username+" "+user.password);
            response.send({status:200, data: res});
        });
    }else{
        response.statusCode = 401;
        response.send({
            status:response.statusCode,
            message:'UnAuthorized access..'
        });
    }
});












instance.listen(4080, function(){
    console.log("Server has been started on the PORT 4080..");
});
