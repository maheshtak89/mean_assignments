module.exports = {
    
    validateReq:function(request, response, isValid){
        var isAUth = false;
        var authValues = request.headers.authorization;
        var credentials = authValues.split(" ")[1];
        var data = credentials.split(":");
        var username = data[0];
        var password = data[1];

        if( username === "admin" && password === "admin"){
            isAUth = true;
            return isAUth;
        }else{
            return isAUth;
        }
    },

    authrizedUser:function(username, password, callback){
                        console.log("In AuthorizedUser()..")

                        var express = require('express');
                        var path = require('path');
                        //var dataModel = require('./datamodel');
                        var BodyParser = require('body-parser');
                        var instance = express();
                        var mongoose = require('mongoose');
                        //1.e set the global promise to manage all async calls makde by application using mongoose driver
                        mongoose.Promise = global.Promise;
                        //configure middleware for static files
                            instance.use(
                                express.static(
                                    path.join(__dirname,'./../node_modules/jquery/dist/')
                                )
                                );
                        instance.use(BodyParser.urlencoded({extended:false}));

                        instance.use(BodyParser.json());
                                    mongoose.connect(
                                        "mongodb://localhost/ProductsAppDB",    // this URL is connection string
                                        {useNewUrlParser:true}                  // its, establishing the parser for parsing connection string as per version of Mongo
                                    );
                            var dbConnect = mongoose.connection;
                            if(!dbConnect){
                                console.log("Sorry, Connection is not established..");
                                return; // will return directly..
                            }

                            var userSchema = mongoose.Schema(
                                    {
                                        username: String,
                                        password: String
                                    }
                                );
                            
                            //4.5.3   map the schema with the collection
                            var userModel = mongoose.model(
                                "userModel", //friendly name
                                userSchema,     //schema
                                "userModel"      //collection name
                                );

                            userModel.find({username :username ,password:password}).exec(function(err, res){
                                // if error occured the respond error
                                console.log("Searching user in DB..")
                                if(err){
                                    console.log(err);
                                }//if
                                 else{
                                        if(res){
                                           return callback(true);
                                        }
                                        else{
                                            return callback(false);
                                        }
                                 }
                             
                                });
                            }
                        }
                            