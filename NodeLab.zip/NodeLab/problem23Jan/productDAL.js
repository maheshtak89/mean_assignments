var express = require('express');
var path = require('path');
var BodyParser = require('body-parser');
var validateModule = require('./validateModule')
var instance = express();

var mongoose = require('mongoose');
mongoose.Promise = global.Promise;

    instance.use(
        express.static(
            path.join(__dirname,'./../node_modules/jquery/dist/')
        )
        );

instance.use(BodyParser.urlencoded({extended:false}));

instance.use(BodyParser.json());

            mongoose.connect(
                "mongodb://localhost/ProductsAppDB",    // this URL is connection string
                {useNewUrlParser:true}                  // its, establishing the parser for parsing connection string as per version of Mongo
            );

    var dbConnect = mongoose.connection;
    if(!dbConnect){
        console.log("Sorry, Connection is not established..");
        return; // will return directly..
    }

    var productsSchema = mongoose.Schema(
            {
                ProductId:Number,                       // as per ES6 number not allowed, it should be Number
                ProductName: String,
                CategoryName: String,
                Manufacturer:String,
                Price:Number
            }
        );
    
    //4.5.3   map the schema with the collection
    var productModel = mongoose.model(
        "Products", //friendly name
        productsSchema,     //schema
        "Products"      //collection name
        )

//get()
//get data from rest service
instance.get("/api/products", function(request, response){
    console.log("In GET for Products")

    //var isValid = false;
    //with primary security
            var authValues = request.headers.authorization;
            var credentials = authValues.split(" ")[1];
            var data = credentials.split(":");
            var requname = data[0];
            var reqpwd = data[1];


    validateModule.authrizedUser(requname, reqpwd, function(resp){
        if(resp){
                productModel.find().exec(function(err,res){
                    if(err){
                        console.log(err);
                       
                    }
                    else{
                        // response.statusCode = 401;
                        //         response.send({
                        //             status:response.statusCode,
                        //             message:'UnAuthorized access..'
                        //         });
                         console.log("Products are below :"+resp);
                        response.send({status: 200, data:resp});
                    }
                });
        } else{
                //error
                response.statusCode = 401;
                    response.send({
                        status:response.statusCode,
                        message:'UnAuthorized access..'
                    });
        }
    });
});
    


instance.listen(4080, function(){
    console.log("Server has been started on the PORT 4080..");
})