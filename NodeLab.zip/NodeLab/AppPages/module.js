//1.
var q = require('q');
//2.
var http = require('http');
//3.
module.exports = {
    
    //4. getData() to call service
    // getData:function(options){                  //option is parameter, it will containes service information 

    //     console.log("module starts execution getData() loaded.....1");

    //     //5. to store data create one varibale
    //     var product = "";

    //     //6. create one defer (its promise object)
    //     var defer = q.defer();

    //     //7. create one request 
    //     var request;

    //     //8. if service is not available
    //     if(!options){
    //         defer.reject("Specified URL is not exist...please try with valid URL...");
    //     }else{
    //         //(if options(service) is exist then..)
    //         request = http.request(options, function(response){
    //             response.setEncoding('utf-8');
    //             response.on('data',function(chunk){
    //                 product += chunk;
    //             });//response.on
    //             response.on('end',function(){
    //                 try{
    //                     // if success
    //                     defer.resolve(receivedData);    // if promise success
    //                 }catch(error){
    //                     // if error occured
    //                     defer.reject(); // send error object back
    //                 }//catch
    //             })//response.on
    //         })//http.request
    //             console.log("module else part finished...")
    //     }//else  
    //     console.log("Module before request.end()")
    //     request.end();
    //     return defer.promise;
    // }//getData()

    postData : function(options, data){
        var defer = q.defer();
        var request;
        if(!options){
            defer.reject("Please specify correct URL to reach the service...");
        }else{
            request = http.request(options, function(response){
                response.on('data',function(chunk){
process.stdout.write(chunk);
                });
                response.on('end', function(){
                    try{
                        console.log(receivedJSON);
                        defer.resolve();
                    }catch(error){
                        defer.reject(error);
                    }
                })
            });
        }
        console.log("Pass");
        request.write(data);
        request.end();
        return defer.promise;
    }
}//module.exports