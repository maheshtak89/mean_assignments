//importing module class here
console.log("app1 starts execution.....1");
var callModule = require('./module');
var q = require('q');
console.log("app1 starts execution....2.");
//create service information
var serverDetails = {
    host:'http://apiapptrainingservice.azurewebsites.net',
    path:'/api/Products',
    method:'GET'
}

//to store information, received from REST service
var product = [];

//calling service
callModule.getData(serverDetails).then(function(response){
    console.log("app1 starts execution.....3");
    console.log("BasePrice \t CategoryName \t Description \t Manufacturer \t ProductId \t ProductName \t ProductRowId");
    console.log();
    for(var i=0;i<response.length;i++){ // this loop will iterate till all product data (response)
        console.log("in For loop :"+i)
        console.log(
            response[i].BasePrice+"\t"+
            response[i].CategoryName+"t"+
            response[i].Description+"\t"+
            response[i].Manufacturer+"t"+
            response[i].ProductId+"t"+
            response[i].ProductName+"t"+
            response[i].ProductRowId+"t"+
            response[i].CategoryName+"t"
        )
    }//for loop
}).catch(function(err){
    console.log(err);
});

console.log("Done!");