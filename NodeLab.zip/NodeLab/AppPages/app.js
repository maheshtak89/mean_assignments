var fs = require('fs');
var http = require('http');
var callModule = require('./module')
var callModule1 = require('./module1')
// var serverDetails = {
//     host:'apiapptrainingservice.azurewebsites.net',
//     path:'/api/Products',
//     method:'GET'
// }
// var product = [];


var productPage = fs.readFileSync('./myPage.html');
var server = http.createServer(function(req, res){
    var productData = '';

    if(req.method ==="GET"){
        res.writeHead(200,{'Content-Type':"text/html"});
        res.end(productPage);    
    }

    if(req.method ==="POST"){

            req.on('data',function(prod){
                productData += prod;
            }).on('end', function(){
                // console.log("Product indormation :"+productData.toString());
                // res.end("Data received is :"+productData.toString());
                var product = JSON.parse(productData);
                var options = {
                    http:'apiapptrainingservice.azurewebsites.net',
                    path:'/api/Products',
                    method:'POST',
                    headers:{
                        'COntent-Type':'application/json',
                        'Content-length': JSON.stringify(product).length
                    }
                };
                console.log(JSON.stringify(product).length);
                console.log(product);
                callModule.postData(options, product).then().catch();
                console.log("The received data is :"+ productData.toString());
                res.end('Data received from you is :'+productData.toString());



                //call getdata
                callModule1.getData(options).then(function(response){
                    console.log(response.toString());
                }).catch(function(err){
                    console.log(err);
                });
                console.log("Done!")
            });
            
            
            //calling module here
            // callModule.getData(serverDetails).then(function(response){
            //     console.log("Product Id \t Product Name \t  Based Price \t CategoryName \t Description \t Manufacturer \t Product Raw ID ");
            //     console.log("=========================================================================================================================");
            //     console.log();
            //     for(var i=0; i<response.length;i++){
            //         console.log(response[i].productid+"\t"+response.productname+"\t"+response.basedprice+"\t"+response.categoryname+"\t"+response.description+"\t"+response.manufacturer+"\t"+response.productrowid);
            //     }
            // }).catch(function(err){
            //         console.log(err);
            // });

            // console.log("Done!");
    }
});
// function getJSON(productData){
//     // var product = {};
//     // var keyVales = productData.split("&");
//     // console.log(keyVales);
//     // for(var i=0 ; i<keyVales.length ; i++){
//     //     var keyVal = keyVales[i].split("=");
//     //      //item
//     //     var key = keyVal[0];
//     //     product[key] = keyVal[1];
//     // }//for
//     // return product;
//     console.log(productData.toString());
// }

server.listen(4050);
console.log("Server has been started on port 4050...")

// ///////////////////////////////////////////////////////////////////
// var product = [];

// var optionInfo = {
//     host: 'apiapptrainingservice.azurewebsites.net',
//     path:'/api/Products',
//     method:'GET'
// }

// function get(){
//     http.request(optionInfo, function(resp){
//         resp.setEncoding('utf-8');
//         resp.on('data',function(data){
//             product = JSON.parse(data);
//             product.foreach(function(e){
//                 console.log("Product ID:"+product.productid+"\n"+"Product Name :"+product.productname+"\n"+"Based Price:"+product.basedprice+"\n"+"Category Name:"+product.categoryname+"\n"+"Description:"+product.description+"\n"+"Manufacturer :"+product.manufacturer+"\n"+"Product Row ID:"+product.productrowid)
                
//             })
//         })
//     }).end();
// }

// get();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
