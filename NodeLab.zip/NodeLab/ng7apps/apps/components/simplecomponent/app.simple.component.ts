import {Component} from "@angular/core";
import { strict } from "assert";

@Component({
    selector: "app-simple-component",
    template:`
        <h2> Hi I am Angular Component!!!@@@@</h2>
        <div class="container">
        <strong>{{message}}</strong>
        </div>
        <br/>
        <div class="container">{{10 + 20}}</div>
        <br/>
        <input type="text" class="form-control" [value] = "name"/>
        <br/>
        <a [href]="url">Devcurry</a>
        <br/>
        <input type="button" class="btn btn-success" value="Click me" (click)="print()"/>
        <br/>
        <input type="text" class="form-control" [(ngModel)]="fullName"/><br/>
        <input type="text" class="form-control" [(ngModel)]="fullName"/><br/>
        <input type="text" class="form-control" [(ngModel)]="fullName"/><br/>

        <input type="number" [value]="num1"/><br/>
        <input type="number" [value]="num2"/><br/>
        <input type="number" /><br/>
        <input type="button" value="Add"/>
        <input type="button" value="Sub"/>
        <input type="button" value="Mul"/><br/><br/>
        `
})
export class SimpleComponent{
    message:string;
    name:string;
    url:string;
    fullName:string;
    num1:number;
    num2:number;
    result:number;
    constructor(){
        this.message = "Hello Angular 7, why r u hurry in version";
        this.name = "Ankita Patle";
        this.url = "http://devcurry.com";
        this.num1 = 10;
        this.num2 = 10;
        
        
    }
    print():void{
        this.message = "hey!! Button is clicked!!";
    }
    add():number{
        return this.num1+this.num2;
    }

    
}