var express = require('express');
var instance = express();
var BodyParser = require('body-parser');

var mongoose = require('mongoose');
var validateUser = require('./validateUser')

mongoose.Promise = global.Promise;

instance.use(BodyParser.urlencoded({extended:false}));
instance.use(BodyParser.json());

mongoose.connect("mongodb://localhost/ProductAppDB",{useNewUrlParser:true});

var dbconnect = mongoose.connection;

if(!dbconnect){
    console.log("Conenction not established..");
    return;
}

var userSchema = mongoose.Schema({
    username:String,
    password:String
});

var userModel = mongoose.model("userModel",userSchema,"userModel");

instance.post("/api/user",function(request, response){
    var user = request.body;

   isAuth = validateUser.isValidUser(request, response);
    if(isAuth){
        userModel.create(user,function(err, resp){
            if(err){
                response.statusCode = 500;
                response.send({status:response.statusCode, error:err});
            }
            console.log(resp.username+" "+resp.password)
            response.send({status:200,data:resp});    
        });
    }else{
        response.statusCode = 401;
        response.send({status:response.statusCode,message:"UnAuthorized Access..."});
    }
});


instance.listen(4090, function(){
    console.log("Server started on POST 4090..")  
})
