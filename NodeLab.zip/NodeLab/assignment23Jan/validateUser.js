module.exports = {
    isValidUser: function(request, response){
        var isAuth =false;
        var authValues = request.headers.authorization;
        var credentials = authValues.split(" ")[1];
        var data = credentials.split(":");
        var username = data[0];
        var password = data[1];

        if(username == "admin" && password=="admin"){
            isAuth = true;
            return isAuth;
        }
        return isAuth;
    }
}