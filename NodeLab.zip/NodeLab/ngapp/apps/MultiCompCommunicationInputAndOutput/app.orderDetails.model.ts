export class OrderDetail{
    constructor(
        public orderNo: number,
        public orderType: string,
        public deliveryStatus:boolean,
        public totalPrice: number,
        public id: number
    ){}
}

export const orderDetails:Array<OrderDetail> = new Array<OrderDetail>();
orderDetails.push(new OrderDetail(1,"COD",true,1200,101));
orderDetails.push(new OrderDetail(2,"Online",true,1200,101));
orderDetails.push(new OrderDetail(3,"Prepaid",true,2353,102));
orderDetails.push(new OrderDetail(4,"COD",true,2312,103));
orderDetails.push(new OrderDetail(5,"Online",true,23213,103));
orderDetails.push(new OrderDetail(6,"Prepaid",true,23213,104));
orderDetails.push(new OrderDetail(6,"COD",false,23213,102));
orderDetails.push(new OrderDetail(6,"COD",true,23213,104));
orderDetails.push(new OrderDetail(6,"Prepaid",false,23213,101));
orderDetails.push(new OrderDetail(6,"Online",true,23213,105));

