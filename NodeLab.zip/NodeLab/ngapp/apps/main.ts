//1. Angular Module File
import { NgModule } from "@angular/core";
//2. Import all standard modules
import { BrowserModule } from "@angular/platform-browser";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpModule } from "@angular/http";
//3. Import all components and directives
//import { SimpleComponent } from "./components/simplecomponent/app.simple.component";
import { ProductComponent } from "./components/productcomponent/app.product.component";

import { Category, Categories } from "./models/app.cat.model";
import { Product, Products } from "./models/app.prod.model";
import { CategorySenderComponent } from "./models/app.categorysender.component";
import { ProductReceiverComponent } from "./models/app.productreceiver.component";
import {  CategoryComponent } from "./MultiComponentCOmmunication/app.category.component";
import { ProductComponent1 } from "./MultiComponentCOmmunication/app.product.component";
//import { SampleService } from "./services/app.sample.service";
//import { ProductFormComponent } from "./components/productformcomponent/app.product.form.component";
// import { SimpleCalculatorComponent } from "./components/simplecomponent/app.simple.calculator.component";
//4. Import all services
import { SampleService } from "./services/app.sample.service";
import { SampleserviceComponent } from "./components/sampleservicecomponent/app.sampleservice.component";
import { ProductServiceComponent } from "./components/appproductservicecomponent/app.productservice.component";
import { ProductService } from "./services/app.products.service";
import { CommunicationService } from "./models/app.communication.service";


import { HomeComponent } from "./components/routeComponents/app.home.component";
import { AboutComponent } from "./components/routeComponents/app.about.component";
import { ContactComponent } from "./components/routeComponents/app.contact.component";
import { routing } from "./components/routeComponents/app.route.table";
import { MainComponent } from "./components/routeComponents/app.main.component";

import { ItemList } from "./MultiCompCommunicationInputAndOutput/app.Itemlist.component";
import {  OrderComponent } from "./MultiCompCommunicationInputAndOutput/app.OrderDetails.component";
import { OrderDetail } from "./MultiCompCommunicationInputAndOutput/app.orderDetails.model";
import { ErrorCOmponent } from "./components/routeComponents/app.error.component";
import { AppGuardService } from "./services/app.test.guard.service";

import { DashBoardComponent } from "./components/problem29JanRoutingAuthentication/app.main.component";
import { RegisterComponent } from "./components/problem29JanRoutingAuthentication/app.regiser.component";


@NgModule({
  imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpModule, routing],
  declarations: [
    SampleserviceComponent,
    ProductComponent,
    ProductServiceComponent,
    CategorySenderComponent,
     ProductReceiverComponent,
     CategoryComponent,
     ProductComponent1,
      HomeComponent,
     AboutComponent,
     ContactComponent,
     MainComponent,
     ItemList,
     OrderComponent,
     ErrorCOmponent,
     DashBoardComponent,
     RegisterComponent

  ],
  providers: [SampleService, ProductService, CommunicationService, CategoryComponent, ProductComponent1, ItemList, OrderComponent, AppGuardService],
  // bootstrap: [CategorySenderComponent, ProductReceiverComponent]
  //  bootstrap: [MainComponent]
  bootstrap: [DashBoardComponent]
  // bootstrap: [ItemList]
  // bootstrap: [IndexComponent]
})
export class AppModule {}
//5. Making the AppModule as BootStrap
platformBrowserDynamic().bootstrapModule(AppModule);
