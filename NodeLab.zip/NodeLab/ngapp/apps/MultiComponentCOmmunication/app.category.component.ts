import { Component, OnInit } from "@angular/core";
import { Categories, Category } from "./app.cat.model";

@Component({
    selector: 'category-data',
    templateUrl: './category.html'
})
export class CategoryComponent implements OnInit {
    categories=Categories;
    categoryName:string;
    constructor() {
        this.categoryName = "";
     }
     selectedCategory(c:any){
         this.categoryName = c.categoryName
     }
 
    ngOnInit() { }
}