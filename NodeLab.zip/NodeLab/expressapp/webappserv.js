//1.  Load express
var express = require('express');

    //1.a load the file module, this will be use by static middleware of express
    var path = require('path'); // standard node module


    //1.b   import data model
    var dataModel = require('./datamodel');

    //1.c   load the bodyparser
    var bodyParser = require('body-parser');
//2.  define an Instance of express
var instance = express();

//3. configure all middlewares, call 'use()' method on express instance.

    //3.a middleware for static files
    instance.use(
        express.static(
            path.join(__dirname,'./../node_modules/jquery/dist/')
        )
    );

    //3.b   define express router, for saggrigating url's for html page web requests and rest api requests
    var router = express.Router();
    
    //3.c   add the router object in the express middleware
    instance.use(router);

    //3.d  configure the body-parser middleware
            //3.d.1   use urlencoded as false to read data from http url as querystring/formmodel etc.
    instance.use(bodyParser.urlencoded({extended:false}));
            //3.d.2   use the JSON.parser for body-parsing
            instance.use(bodyParser.json()); 
//4.create web request handlers
            //4.a This will return the home.html from views folder
            //instance.get("/home", function(req,resp){           // callback function takes 2 parameter req and resp
            router.get("/home", function(req,resp){               // here instead of instance we can directly use router, because we already configure router
                resp.sendFile(
                    "home.html",
                    {
                    root:path.join(__dirname,"./../views")
                    }, function(err){
                             //console.log("Resource Not found.."+err.message);
                       }
                );
            });

//5. create REST api request handlers
            //getall
            instance.get("/api/products",function(req,resp){ // 1st param we r generating URL
               console.log("In GET");
                    //5.a    read headers from AUthorization values
                    var authValues = req.headers.authorization;
                    //5.b process authvalues
                    var credentials = authValues.split(" ")[1];
                    var data = credentials.split(":");
                    var username = data[0];
                    var password = data[1];

                    //5.c May access UserModel from dataBase(????????????????)

                    if(username == "mahesh" && password == "mahesh"){
                        resp.send(JSON.stringify(dataModel.getData()));
                    }else{
                        resp.statusCode = 401;
                        resp.send({
                            status:resp.statusCode,
                            message:'UnAuthorized access..'
                        });
                    }
                    
                    //resp.write('In GET');
            });//instance.get()
            //getById
            instance.get("/api/products/product/:id",function(req, resp){
                console.log("In GET for id :"+req.params.id);
                resp.send(JSON.stringify(
                    dataModel.getById(req.params.id)
                    )
                );
            });
            instance.post("/api/products", function(req, resp){
                console.log("In POST");
                    var data = req.body;    // read the request body
                    //console.log(data);
                    var responseData = dataModel.addData(data);
                    resp.send(JSON.stringify(responseData));
                    //resp.write('In POST');
                   // resp.send("we received data and will look into it..");
            });//instamce.post()

           instance.put("/api/products/update/:id",function(req,resp){
            var id = req.params.id;
            var prod = req.body;

            var receivedData = dataModel.updateData(prod,id);
            resp.send(JSON.stringify(receivedData));
            
           });
            instance.delete("/api/products/delete/:id", function(req,resp){
                console.log(req.params.id);
            });
            // instance.delete("/api/products/delete/:id", function(req, resp){
            //     var id = req.params.id;
            //     var remainProducts = dataModel.deleteData(id);
            //     resp.send(JSON.stringify(remainProducts));
            // });
           
//6. start listening
instance.listen(4070, function(){
    console.log("listening from port 4070 has been started...")
});
