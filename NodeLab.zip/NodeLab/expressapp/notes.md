**Technologies:**
	- Node.js
	- Express.js
	- MongoDB
		: - download and Install (MongoDB.com) with MongoConmpass installation. 
			- windows 64bit
	- Mongoos
	- Passport
	- JWT

	
==================================================================================================================================

**Express JS**
**===========**
- This is a Framework works on Node.js
- used to create webapplications, mobile application and API's, Middleware logic, Routing.
- can design Singlpage as well as multipage aaplication also.
- Middleware : native to http pipeline ( Auth, Authr, Body Formatter, CORS, Error )
CORS : Cross Origin Resource Session

- Routing : 
	


**============================================================================================================================**
format for authorization:

 headers :{
	 "AUTHORIZATION": 'Basic btoa
	 	(username:password)'
 }

 headers :{
	 "AUTHORIZATION": 'Bearer grant_type <TOKKEN>'
 }
 



 **Problem statements**

 - Create a user model collection in Mongo which will store, userId and Password.
 - Create a API which should be able to create users. But to create user the header must passed administartors creadentials.
 - Provide the access to REST api for Products, based on login that is received from header.
 - Every REst api should validate used first before gaining access.

 Please follow the following structure:
	1- Create a user model.js which will contain logic for user regstration.
	2- Create DAL.js which will contain API logic for Products.
	3- App.js / webserver.js will use these two modules to complete the application.
		If login user is invalidated then generate the error message as "Please register with URL of User registration".