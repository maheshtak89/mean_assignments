var Products = [
    {'id':101, name:'Bharat'},
    {'id':102, name:'Arjun'},
    {'id':103, name:'Krishna'},
    {'id':104, name:'Karan'}
    
]

//creating custom node module
module.exports = {
    //get method for retriving data
    getData: function() {
        return Products;// return Product data
    },
    getById:function(id){
        return Products.filter((prod)=>{
            return prod.id == id;
        });
    },
    //add method for adding data
    addData:function(prd){
        //here we r adding data in Product array
        Products.push(prd);
        return Products;// return Product data
    },
    updateData:function(prod, id){
        Products.forEach(element => {
            if(element.id == id){
                element.id = id;
                element.name = prod.name;
            }
        });
        return Products;
    },
    deleteData:function(pid){
        var index;

        var dt = Products.find(function(item,i){
            if(item.id == pid){
                index = i;
                return i;
            }
        });
        Products.splice(index, pid);
        return Products;
    }
}