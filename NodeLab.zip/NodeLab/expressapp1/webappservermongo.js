

//declaration
//1.  Load express
var express = require('express');

var path = require('path');
var dataModel = require('./datamodel');
var BodyParser = require('body-parser');
var validateModule = require('./validateModule')
var instance = express();

//1. d Loading Mongoose driver
var mongoose = require('mongoose');
//1.e set the global promise to manage all async calls makde by application using mongoose driver
mongoose.Promise = global.Promise;


//configuration
    //configure middleware for static files
    instance.use(
        express.static(
            path.join(__dirname,'./../node_modules/jquery/dist/')
        )
        );

//declare router for navigating URL
var router = express.Router();
//configure router
instance.use(router);

instance.use(BodyParser.urlencoded({extended:false}));

instance.use(BodyParser.json());

//4.5   Model schema mapping with collection of MongoDB and establishing connection with it.
            mongoose.connect(
                "mongodb://localhost/ProductsAppDB",    // this URL is connection string
                {useNewUrlParser:true}                  // its, establishing the parser for parsing connection string as per version of Mongo
            );
    //4.5.1  get the connection object
    // if db connect is not undefined then the connection is successfull.
    var dbConnect = mongoose.connection;
    if(!dbConnect){
        console.log("Sorry, Connection is not established..");
        return; // will return directly..
    }

    //4.5.2     define Schema (Recommended to have same attributes as per the collection)
    var productsSchema = mongoose.Schema(
            {
                ProductId:Number,                       // as per ES6 number not allowed, it should be Number
                ProductName: String,
                CategoryName: String,
                Manufacturer:String,
                Price:Number
            }
        );
    
    //4.5.3   map the schema with the collection
    var productModel = mongoose.model(
        "Products", //friendly name
        productsSchema,     //schema
        "Products"      //collection name
        )

//get
instance.get("/api/products/",function(request, response){
        // make call to DB for a collection mapped with model and expect all documents from it.
        productModel.find().exec(function(err, res){
            // if error occured the respond error
            if(err){
                response.statusCode = 500;
                response.send({ status : response.statusCode, error:err});
            }//if
            response.send({ status: 200, data: res});
        });
});
//post()
//inserting data to rest service
instance.post("/api/products/", function(request, response){
    //parsing posted data into JSON
    var prd = {
        ProductId: request.body.ProductId,
        ProductName: request.body.ProductName,
        CategoryName: request.body.CategoryName,
        Manufacturer: request.body.Manufacturer,
        Price: request.body.Price,
    };
    //pass the parsed object to "create()" method
    productModel.create(prd, function(err, res){
        if(err){
            response.statusCode = 500;
            response.send({ status : response.statusCode, error:err});
        }
        response.send({status:200, data: res});
    });
});



instance.listen(4050, function(){
    console.log("Server has been started on the PORT 4050..");
});
