

//declaration
//1.  Load express
var express = require('express');

var path = require('path');
var dataModel = require('./datamodel');
var BodyParser = require('body-parser');
var validateModule = require('./validateModule')
var instance = express();

//1. d Loading Mongoose driver
var mongoose = require('mongoose');
//1.e set the global promise to manage all async calls makde by application using mongoose driver
mongoose.Promise = global.Promise;


//configuration
    //configure middleware for static files
    instance.use(
        express.static(
            path.join(__dirname,'./../node_modules/jquery/dist/')
        )
        );

//declare router for navigating URL
var router = express.Router();
//configure router
instance.use(router);

instance.use(BodyParser.urlencoded({extended:false}));

instance.use(BodyParser.json());

//4.5   Model schema mapping with collection of MongoDB and establishing connection with it.
            mongoose.connect(
                "mongodb://localhost/ProductsAppDB",    // this URL is connection string
                {useNewUrlParser:true}                  // its, establishing the parser for parsing connection string as per version of Mongo
            );
    //4.5.1  get the connection object
    // if db connect is not undefined then the connection is successfull.
    var dbConnect = mongoose.connection;
    if(!dbConnect){
        console.log("Sorry, Connection is not established..");
        return; // will return directly..
    }

    //4.5.2     define Schema (Recommended to have same attributes as per the collection)
    var productsSchema = mongoose.Schema(
            {
                ProductId:Number,                       // as per ES6 number not allowed, it should be Number
                ProductName: String,
                CategoryName: String,
                Manufacturer:String,
                Price:Number
            }
        );
    
    //4.5.3   map the schema with the collection
    var productModel = mongoose.model(
        "Products", //friendly name
        productsSchema,     //schema
        "Products"      //collection name
        )


//routing URL request to different pages
    router.get("/home", function(requst, response){
            response.sendfile(
                    "home.html",
                        {root:path.join(__dirname,"./../views")
                        }
            );
    });

//get()
//get data from rest service
instance.get("/api/products", function(request, response){
    console.log("In GET()");


    //with primary security
    var isAuth = validateModule.validateReq(request, response);
    if(isAuth){
        var receivedData = dataModel.getData();
    response.send(JSON.stringify(receivedData));
    }else{
        response.statusCode = 401;
        response.send({
            status:response.statusCode,
            message:'UnAuthorized access..'
        });
    }

    
});
//get
//get by id, single record retreiving
instance.get("/api/products/product/:id",function(request, response){
    console.log("In getById for id:"+request.params.id);
    var isAuth = validateModule.validateReq(request, response);
    if(isAuth){
        var receivedData = dataModel.getById(request.params.id);
        response.send(JSON.stringify(receivedData));
    }else{
        response.statusCode = 401;
        response.send({
            status:response.statusCode,
            message:'UnAuthorized access..'
        });
    }
    
    
});
//post()
//inserting data to rest service
instance.post("/api/products/", function(request, response){
    var bodyData = request.body;

    var isAuth = validateModule.validateReq(request, response);
    if(isAuth){
        var receivedData = dataModel.addData(bodyData);
        response.send(JSON.stringify(receivedData));
    }else{
        response.statusCode = 401;
        response.send({
            status:response.statusCode,
            message:'UnAuthorized access..'
        });
    }
    
});
//put()
instance.put("/api/products/update/:id", function(request, response){
    var id = request.params.id;
    var BodyData = request.body;
    var isAuth = validateModule.validateReq(request, response);
    if(isAuth){
        var receivedData = dataModel.updateData(BodyData, id);
        response.send(JSON.stringify(receivedData));
    }else{
        response.statusCode = 401;
        response.send({
            status:response.statusCode,
            message:'UnAuthorized access..'
        });
    }
    
});
//delete()
//delete record from array of object, based on specific ID
instance.delete("/api/products/delete/:id", function(request, response){
    console.log("In delete for id :"+request.params.id)
    var id = request.params.id;
    var isAuth = validateModule.validateReq(request, response);
    if(isAuth){
        var receivedData = dataModel.deleteData(id);
        response.send(JSON.stringify(receivedData));
    }else{
        response.statusCode = 401;
        response.send({
            status:response.statusCode,
            message:'UnAuthorized access..'
        });
    }
    
});













instance.listen(4050, function(){
    console.log("Server has been started on the PORT 4050..");
});
