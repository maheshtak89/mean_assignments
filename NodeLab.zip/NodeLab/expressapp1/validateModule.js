module.exports = {
    
    validateReq:function(request, response){
        var isAUth = false;
        var authValues = request.headers.authorization;
        var credentials = authValues.split(" ")[1];
        var data = credentials.split(":");
        var username = data[0];
        var password = data[1];

        if( username === "mahesh" && password === "mahesh"){
            isAUth = true;
            return isAUth;
        }else{
            return isAUth;
        }
    }
}