//1. simple tuple
//tuple contain first val as string and second as number
var val;
//rules 
//1. value types must be followed in tuple
//2. tuple must be initialized
val = ["A", 101]; //initilaization
//val = [101,"A"];    // error
console.log(val[0] + " " + val[1]);
var productRecord; // defining a reference type of tupleData
//initializing tupleData reference type
productRecord = [1, { productID: 101, productName: "Desktop" }];
//adding elements in tuple (tupleRecord)
productRecord.push([2, { productID: 102, productName: "Router" }]);
productRecord.push([3, { productID: 103, productName: "Modem" }]);
//console.log(productRecord)
for (var _i = 0, productRecord_1 = productRecord; _i < productRecord_1.length; _i++) {
    var p = productRecord_1[_i];
    console.log(p);
}
