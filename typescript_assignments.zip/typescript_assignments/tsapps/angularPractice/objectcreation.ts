class Person{
    constructor(name){
        this.name = name;
    }
}