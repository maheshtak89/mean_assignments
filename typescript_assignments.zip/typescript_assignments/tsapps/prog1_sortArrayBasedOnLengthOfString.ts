let arr = ["Sanjay", "Radha", "Dnyaneshwar", "Bharat"];

let newArr = [];

for(var i=1;i<arr.length;i++){
    for(var j=0;j<arr.length;j++){
        let str1 = arr[i-1];
        let str2 = arr[j];

     //   console.log(str1+" "+str2);
        let str1Len = str1.length;
        let str2Len = str2.length;

        if(str1Len >= str2Len){
            newArr.push(str2);
        }
    }
}

console.log("Original array : "+arr);
console.log();
console.log("Soreted array : "+newArr);