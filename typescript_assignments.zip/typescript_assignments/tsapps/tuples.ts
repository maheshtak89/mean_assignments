//1. simple tuple
//tuple contain first val as string and second as number
let val:[string, number];
//rules 
    //1. value types must be followed in tuple
    //2. tuple must be initialized
val = ["A",101]; //initilaization
//val = [101,"A"];    // error
console.log(`${val[0]} ${val[1]}`);

//////////////////////////////////////////////////////////////////////////////////////////////////////

//define tuple using "type" for complex data
//tuple data is type and [number,{}] is the type of TupleData
type TupleData=[number,{}];

let productRecord: TupleData;       // defining a reference type of tupleData
//initializing tupleData reference type
//productRecord = [1,{productID:101, productName: "Desktop"}];
productRecord = [0,{}];

//adding elements in tuple (tupleRecord)
productRecord.push([2,{productID:102, productName:"Router"}])
productRecord.push([3,{productID:103, productName:"Modem"}])

//console.log(productRecord)

for(let p of productRecord){
    console.log(p);
}