// declaration with default initialization
let names:[] =[]; 

names.push('sanjay');
names.push('Akshay');
names.push('Ajay');
names.push('Sanjay');

//Tradetional iteration using for loop
console.log('for loop')
for(let i=0; i<names.length;i++){
    console.log('name at $[i] is $[names{i}}');
}
console.log();

//ES 5 Iteration using for .. in loop
// simplation of for loop
console.log("Using for in loop");
for(let i in names){
    console.log('name at $[i] is $[names{i}}');
}

console.log();

//iterators using for .. of loop
//internally uses Symbol.iterator() of ES6
//Typescript uses for loop for Symbol.iterator
console.log("Using for of loop");

for(let n of names){
    console.log('Names = ${n}');
}
console.log();