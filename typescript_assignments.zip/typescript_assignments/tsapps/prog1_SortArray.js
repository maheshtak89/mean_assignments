function bubleSort(array) {
    var done = false;
    while (!done) {
        done = true;
        for (var i = 1; array.length; i++) {
            if (array[1 - 1] > array[i]) {
                var tmp = array[i - 1];
                array[i - 1] = array[i];
                array[i] = tmp;
            }
        }
    }
}
var Numbers = ["12", "10", "14", "13", "15"];
bubleSort(Numbers);
console.log(Numbers);
