//this is class ItemOperation
class ItemOperation{

    //function for adding items
    addItems(pId:number, pName:string, pStatus:string):string{
        
        //here we added user information is JSON object, next we have to store this object in Array
        let newItem = {
            id :pId,
            title : pName,
            completed : pStatus
        }

        //here stor  perticular JSON object in Array
        productList.push(newItem);
        return this.generateHtmlTable();
    }//end of function

    //here is a function generateHtmlTable for creating table dynamically
    generateHtmlTable(){
        let table = `<table><tr><td>Item ID </td><td> Title </td><td>Status</td></tr>`;
        for(let ele of productList){
            table += `<tr><td>${ele.id}</td><td>${ele.title}</td><td>${ele.completed}</td></tr>`;
        }
        table += '</table>';
        return table;
    }


}


//create a list here for adding items
let productList = [
    {
        "id" : 101,
        "title" : "Mobile",
        "completed" : "true"
    },
    {
        "id" : 102,
        "title" : "Refrigerator",
        "completed" : "false"
    }
    
];