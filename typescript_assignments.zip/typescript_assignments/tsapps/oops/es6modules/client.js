"use strict";
exports.__esModule = true;
//importing class here
var logic_1 = require("./logic");
var strOp = new logic_1.StringOperations();
var str = "Mahesh SkyTech Services";
console.log("Length of " + str + " = " + strOp.getLength(str));
console.log("Upper case of " + str + " = " + strOp.changeCase(str, "U"));
console.log("Lower case of " + str + " = " + strOp.changeCase(str, "L"));
