class MathClass{
    // private x:number = 0;
    // private y:number = 0;
    private z:number = 0;
    
    //here constructor keyword used to write constrcutor
    constructor(public x:number, public y:number){
        // this.x= x;
        // this.y= y; 
    }

    //add() method
    add():number{
        this.z = this.x + this.y;
        return this.z;
    }

    //sub() method
    sub():number{
        this.z = this.x - this.y;
        return this.z;
    }
}

//create object of MathClass with 2 arguments
let mObj = new MathClass(20,30);

console.log(`Add = ${mObj.add()}`);
console.log(`Add = ${mObj.sub()}`);
