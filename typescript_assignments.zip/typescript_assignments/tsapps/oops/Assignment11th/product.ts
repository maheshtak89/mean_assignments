class Productt{
    constructor( public prodId:number, public prodName:string){}
}

class ProductLogicc{
    product:Productt;
    products:Array<Productt>;
    constructor(){
        this.product = new Productt(0,"");
        this.products = new Array<Productt>();

        this.products.push(new Productt(101,"p1"));
        this.products.push(new Productt(102,"p2"));
        
    }

    //getter method
    getProducts():Array<Productt>{
        return this.products;
    }

    //setter method
    saveProduct(p:Productt):Array<Productt>{
        this.products.push(p);
        return this.products;
    }
}


//another class
class ProductOperations extends ProductLogic{
    constructor(){          // derived class must and should have a constructor which called to based call constructor
        super();            // calling to based class cnstructor
    }

    //this method will search Products by ID
    getProductById(id:number):Product{
        //write logic to search product

        return new Product(0,"----");
    }

    getProductByCategory(cat:string):Array<Product>{
        //logic
        return this.products;
    }
}

class Presenter{
    generateTable():String{
        let Products = [
            {ProdId:101, ProdName: "P1"},
            {ProdId:102, ProdName: "P2"}
        ];

        let table = "<center><table border='2' cellspacing='2' cellpadding='2' align='center'><tr><td>ProductID</td><td>ProductName</td></tr>";
        for(let p of Products){
            table +=    `<tr align='center'><td>${p.ProdId}</td><td>${p.ProdName}</td></tr>`;
        }
        table += "</table></center>";
        return table;
    }
}


let prdOperation = new ProductOperations();

console.log(JSON.stringify(prdOperation.getProducts()));

let prd = new Product(103,"P3");
console.log(JSON.stringify(prdOperation.saveProduct(prd)));