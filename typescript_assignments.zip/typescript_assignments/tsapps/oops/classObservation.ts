

//class demoES6
class DemoES6{
    summation(...values:number[]):number{
    let sum:number = 0;
        if(values.length > 0){
            values.forEach((v,i)=>{
                sum = sum+v;
            });
        }
    return sum;
    }

    // method overloading not possible
    
    // add(x:number):number{
    //     return 0;
    // }

    // add(x:number, y: string):number{
    //     return 0;
    // }
}


//ce=reating object
let obj = new DemoES6();

console.log(`2 parameters ${obj.summation(2,3)}`);
console.log(`3 parameters ${obj.summation(4,5,2)}`);
console.log(`4 parameters ${obj.summation(6,7,2,1)}`);

console.log(obj.add(2));