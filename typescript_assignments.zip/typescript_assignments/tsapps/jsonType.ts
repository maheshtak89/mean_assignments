//this is json object, also known as literal
let product = {
    prodcutID:101,
    productName:"Laptop"
};

//1. JSON serialization aka string parsing for JSON
console.log(JSON.stringify(product));
//2. Getting length of all keys of JSON object
let info = Object.keys(product).length;
console.log("Length of JSON data :"+info);

//3. Read all property names
for(let p in Object.keys(product)){
    console.log(p);
}

//4. get the name of property
for(let pname of Object.keys(product)){
    console.log(pname);
}



let namesData =[];
namesData.push({id:102, name:"A"});
namesData.push({id:103, name:"B"});
namesData.push({id:104, name:"C"});

