//variable name must start from lower case
//use camel-case fpr multi word varoable name
var firstName = "Mahesh";
var middleName = "Ravindra";
var lastName = "Tak";
//1. concatinate using old JS style (ES3 to 5)
var fullNameOld = firstName + " " + middleName + " " + lastName;
console.log("Full Name with old style : " + fullNameOld);
var fullNameWithNewTemplate = '${firstName}${middleName}${lastName}';
console.log('with Template string ${fullNameWithNewTemplate}');     //not working

