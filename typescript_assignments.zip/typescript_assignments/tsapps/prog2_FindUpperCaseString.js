var arr1 = ["Sanjay", "Radha", "dnyaneshwar", "bharat", "ram"];
var arr2 = [];
//console.log(arr1[3].charAt(0));
for (var i = 0; i < arr1.length; i++) {
    for (var j = 0; j < arr1.length; j++) {
        var char1 = arr1[i].charAt(0);
        var char2 = arr1[j].charAt(0);
        if (char1.toUpperCase() == char2) {
            arr2.push(arr1[i]);
        }
    }
}
console.log("Original array : " + arr1);
console.log();
console.log("Array of Uppercase element : " + arr2);
